﻿using System;
using System.IO;
using System.Windows.Forms;

namespace Funzione_gui
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void clear()
        {
            tbClassName.Text = "";
            tbF.Value = 0;
            tbM.Value = 0;
        }

        private void binsert_Click(object sender, EventArgs e)
        {
            int tot = 0, num_m = 0, num_f = 0;
            int pf = 0, pm = 0;

            if (tbClassName.Text.Length != 0)
            {
                num_m = Convert.ToInt32(tbM.Value);
                num_f = Convert.ToInt32(tbF.Value);

                tot = num_m + num_f;
                pf = (int)Math.Round((double)(100 * num_f) / tot);
                pm = (int)Math.Round((double)(100 * num_m) / tot);
                //prima seconda terza quarta
                //classe perm perf tot
                dataGridView1.Rows.Add(tbClassName.Text, pm + "%", pf + "%", tot);
                clear();
            }
        }

        private void bexp_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog path = new FolderBrowserDialog())
            {
                if (DialogResult.OK == path.ShowDialog())
                {
                    string selected_path = path.SelectedPath;
                    //MessageBox.Show(fileName);
                    //TextWriter writer = new StreamWriter("C:\\Users\\USER\\Documents\\repos\\scuola\\Funzione_gui_solution\\Alunni.txt");
                    TextWriter writer = new StreamWriter(selected_path + "\\Alunni.txt");
                    writer.WriteLine("Registrati in data: " + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss tt"));
                    writer.WriteLine("---------------------------------");
                    writer.WriteLine(" CLASSE | Maschi | Femmine | TOTALE |");
                    writer.WriteLine("---------------------------------");
                    for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                    {
                        for (int j = 0; j < dataGridView1.Columns.Count; j++)
                        {
                            writer.Write("\t" + dataGridView1.Rows[i].Cells[j].Value.ToString() + "\t" + "|");
                        }
                        writer.WriteLine("");
                        writer.WriteLine("---------------------------------");
                    }
                    writer.WriteLine(" ");
                    writer.WriteLine("     Made with <3 by Fede.Tensi     ");
                    writer.WriteLine(" ");
                    writer.WriteLine("---------------------------------");
                    writer.Close();
                    MessageBox.Show("Dati esportati!\nIn: " + selected_path, "INFO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
    }
}
